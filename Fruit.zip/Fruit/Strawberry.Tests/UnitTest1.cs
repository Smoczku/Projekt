﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Strawberry.Web.DataAccessLayer;
using Strawberry.Web.Models;

namespace Strawberry.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod] // Repository
        public void TestMethod1()
        {
        }
    }
}
